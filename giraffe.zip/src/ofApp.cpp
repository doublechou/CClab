#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    // make the background black
    ofBackground(0);
    // don't automatically black out the window each frame
    ofSetBackgroundAuto(false);

    img0.load("images/img5.png");
    img1.load("images/img1.png");
    img2.load("images/img2.png");
    img3.load("images/img3.png");
    img4.load("images/img4.png");
    candy.load("images/skittles.png");
    man.load("images/man.jpg");
    giraffe.load("images/giraffe.png");



    // make 350 FireworkParticles and put them in an array
    int numParticles = 350;
    for (int i = 0; i < numParticles; i++) {
        FireworkParticle firework;
        fireworks.push_back(firework);
    }

    fireworksRestart();
}

void ofApp::fireworksRestart() {
    // randomly generate a new position
    ofPoint position;
    position.set(ofRandomWidth(), ofRandomHeight());

    // randomly generate a new color
    ofColor fireworkColor;
    //fireworkColor.setHsb(ofRandom(255), 255, 192);

    // go through our fireworks vector and setup each firework in it
    for (int i = 0; i < fireworks.size(); i++) {
        fireworkColor.setHsb(ofRandom(255), 255, 192);
        fireworks[i].setup(ofGetMouseX(), ofGetMouseY(), fireworkColor);

    }

}

//--------------------------------------------------------------
void ofApp::update(){

    // go through our fireworks vector and update each firework in it
    for (int i = 0; i < fireworks.size(); i++) {
        fireworks[i].update();
    }

    // check whether fireworks are still active
    // when alpha <= 0, firework is dead
    // can just check one firework since they all are born at the same time and
    // expire at the same time
//    if (fireworks[0].alpha <= 0) {
//        fireworksRestart();
//    }
}

//--------------------------------------------------------------
void ofApp::draw(){

    // set the color to a very translucent black
    ofSetColor(0, 0, 0, 18);

    // draw a rectangle over the screen in a very translucent black
    // this is how we get the 'streaks' -- we're just drawing over past frames.
    ofDrawRectangle(0, 0, ofGetWidth(), ofGetHeight());

    // go through our fireworks vector and draw each firework in it
    for (int i = 0; i < fireworks.size(); i++) {

        fireworks[i].draw();
        giraffe.draw(ofGetMouseX()-30, ofGetMouseY()-100,100,150);


    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

    fireworksRestart();
    ofSetColor(255,255,255);
    man.draw(-200,0);




}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){

}
